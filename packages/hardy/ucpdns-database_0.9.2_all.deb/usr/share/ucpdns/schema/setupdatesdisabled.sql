CREATE OR REPLACE FUNCTION SetUpdatesDisabled(
	status int
) RETURNS varchar AS $$
BEGIN
	UPDATE updates_disabled SET disabled = status;
END; $$ LANGUAGE plpgsql;
